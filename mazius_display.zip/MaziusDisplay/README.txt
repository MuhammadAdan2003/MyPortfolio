## License

Coconat is available under the SIL Open Font License v1.1

See [OFL.txt](OFL.txt) for more details.

## About Author

Collletttivo open-source type foundry. Open to collaborations. Designed by Sara Lavazza. 

Submit your work using Collletttivo typefaces at collletttivo@gmail.com